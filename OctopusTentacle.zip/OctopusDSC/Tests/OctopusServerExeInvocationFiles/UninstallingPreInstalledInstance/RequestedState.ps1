return @{
  Ensure = "Absent";
  Name = "Octopus"
  State = "Stopped";
}
